# CF7-Export-CSV

This is a plugin for storing data of Contact Form 7 forms to Database and Export CSV.

[Download](https://github.com/ImDR/CF7-Export-CSV/raw/master/cf7-export-csv.zip)