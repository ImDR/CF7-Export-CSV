<?php

/*
Plugin Name: CF7 Export CSV
Plugin URI: http://imdr.github.io/cf7-export-csv
Description: This is a plugin for storing data of Contact Form 7 forms to Database and Export CSV.
Author: Dinesh Rawat
Author URI: http://imdr.github.io/
Version: 1.0
*/

include_once('inc/cf7-export-csv-page.php');
include_once('inc/cf7-save-data.php');


/*-----------database table creation-----------*/
register_activation_hook( __FILE__, 'cf7_export_csv_create_db' );

function cf7_export_csv_create_db() {
	global $wpdb;
	$charset = $wpdb->get_charset_collate();
	$table_name = $wpdb->prefix.'cf7_export_csv_db';
	if($wpdb->get_var("show tables like '$table_name'") != $table_name){
		$sql = "CREATE TABLE $table_name ( 
			`id` INT NOT NULL AUTO_INCREMENT , 
			`submission_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP , 
			`form_id` INT , 
			`form_values` TEXT , 
			UNIQUE (`id`))$charset;";
			
		require_once(ABSPATH.'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}
	
}