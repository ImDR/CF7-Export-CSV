License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html