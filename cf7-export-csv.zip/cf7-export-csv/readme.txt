=== CF7 EXPORT CSV ===
Contributors: imdr
Donate link: https://imdr.github.io/cf7-export-csv/donate
Tags: comments, spam
Requires at least: 4.7
Tested up to: 4.8
Stable tag: 4.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
CF7 Export CSV is a plugin for storing data of Contact Form 7 forms into the database and exporting data as CSV files.
 
== Description ==
 
CF7 Export CSV is a plugin for storing data of Contact Form 7 forms into the database and exporting data as CSV files. It is a free alternative of Contact Form 7 Database, Contact Form Submissions and CFDB Plugin. This plugin is totally free. There is no limit in adding form’s data into the database. You can add multiples form’s data into database.

= Docs & Support =

You can find [docs](https://github.com/ImDR/CF7-Export-CSV)

= CF7 EXPORT CSV Needs Your Support =

If you are enjoying using CF7 EXPORT CSV and finding it useful, please consider [__making a donation__](https://imdr.github.io/cf7-export-csv/donate). Your donation will help in encouraging and support plugin's development and better user support.

== Installation ==
 
1. Download cf7-export-csv.zip and extract it from wp-content\plugins (plugin folder).
1. Activate CF7 Export CSV plugin. It shows a message if Contact Form 7 is not downloaded or not activated.

== Frequently Asked Questions ==

1.You can find [docs](https://github.com/ImDR/CF7-Export-CSV)
 
== Screenshots ==
 
1. screenshot-1.jpg
2. screenshot-2.jpg
3. screenshot-3.jpg
4. screenshot-4.jpg
5. screenshot-5.jpg
6. screenshot-6.jpg
7. screenshot-7.jpg
8. screenshot-8.jpg
9. screenshot-9.jpg
 
== Changelog ==

= 1.6 =
Get more information, see [here](https://github.com/ImDR/CF7-Export-CSV).
 
== Upgrade Notice ==
 
= 1.6 =
Get more information, see [here](https://github.com/ImDR/CF7-Export-CSV).
